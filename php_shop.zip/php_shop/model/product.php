<?php
class Product
{

//Lấy 10 sản phẩm được quan tâm nhất
    function get_hot_product()
    {
        global $link;//$link = $_GLOBAL['link'];
        $sql = 'SELECT `id`, `name`, `price`, `img_url` 
			FROM `nn_product` 
			WHERE `active` = 1
			ORDER BY `view` desc
			LIMIT 0,10';
        $rs_hot = mysqli_query($link, $sql);
        $data = [];
        while($row = mysqli_fetch_assoc($rs_hot))
        {
            $data[]=$row;
        }
        return $data;
    }

//Lấy 20 sản phẩm moi nhất
    function get_new_product()
    {
        $link = $GLOBALS['link'];
        $sql = 'SELECT `id`, `name`, `price`, `img_url` 
			FROM `nn_product` 
			WHERE `active` = 1
			ORDER BY `id` desc
			LIMIT 0,20';
        return $rs_new = mysqli_query($link, $sql);
    }
}
?>