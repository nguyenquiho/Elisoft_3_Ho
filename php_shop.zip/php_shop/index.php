<?php
include('module/header.php');

function view($view,$data)
{
    foreach($data as $k => $v)
    {
        $$k=$v;
    }
    //extract($data);
    include("module/{$view}.php");
}

if (!empty($_GET['mod']))
    $mod = $_GET['mod'];
else
    $mod = 'home';

if($mod == 'home')
{
    include('model/product.php');
    $product = new Product();
    $rs_hot = $product->get_hot_product();
    $rs_new = $product->get_new_product();
    view('home',['rs_hot'=>$rs_hot,'rs_new'=>$rs_new]);
}


include('module/footer.php');
?>
             
            
