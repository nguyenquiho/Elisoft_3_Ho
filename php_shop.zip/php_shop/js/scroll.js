$(function() {
    $(".anyClass").jCarouselLite({
        btnNext: ".next, .nextsmall",
        btnPrev: ".prev, .prevsmall"
    });
});