<div class="col2_center">
	Testing...
    <?php 
		if(isset($_SESSION['id']))
			echo 'Da dang nhap';
		else
			echo 'Chua dang nhap';
	?>
</div>