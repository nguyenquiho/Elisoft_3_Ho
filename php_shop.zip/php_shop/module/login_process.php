<div class="col2_center">
<?php
	$email= $_POST['email'];
	$pass=hash('sha512',$_POST['pass']);
	
	$sql="SELECT `id`,`name` FROM `nn_user` WHERE `email`='$email' and `password`='$pass'";
	$rs=mysqli_query($link,$sql);
	//kiem tra co dong nao duoc tra ve khong
	if(mysqli_num_rows($rs)==0)
		echo 'Email or Pass khong dung!';
	else
	{	
		$r=mysqli_fetch_assoc($rs);
		$_SESSION['id']=$r['id'];
		$_SESSION['name']=$r['name'];
		//echo 'Dang nhap thanh cong';
		//chueyn trang bang php
		header('location:?mod=home');
	}
?>
</div>