<?php
	//huy session
	unset($_SESSION['id']);
	unset($_SESSION['name']);
	//chuyen trang
	header('location:?mod=login');
?>