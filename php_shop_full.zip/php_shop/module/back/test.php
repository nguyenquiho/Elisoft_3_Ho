testing

<?php
	//echo password_hash('123',PASSWORD_DEFAULT);
	//$test = 5;
	
	
	//echo $test;
	//$_SESSION['test']++;
	echo $_SESSION['id'];
?>