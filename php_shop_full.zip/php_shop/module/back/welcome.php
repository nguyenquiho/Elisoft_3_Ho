<?php
	echo 'Xin chào quản trị ',$_SESSION['admin_name'];	
?>