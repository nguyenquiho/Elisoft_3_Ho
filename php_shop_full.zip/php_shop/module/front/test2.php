testing

<?php	
	//echo $test;
	
	echo $_SESSION['id'];
?>