<?php
dd($products);
?>