<body>
    <h2>Elishop thông báo bạn đã tạo tài khoản thành công</h2>
    <p>Vui lòng đăng nhập vào cửa hàng để có trải nghiệm tốt nhất và nhận được những ưu đãi bất ngờ ngay từ bây giờ</p>
</body>