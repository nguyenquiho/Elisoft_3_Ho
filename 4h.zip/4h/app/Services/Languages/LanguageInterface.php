<?php
namespace App\Services\Languages;

interface LanguageInterface
{
    function toASCII($tr);
}
?>