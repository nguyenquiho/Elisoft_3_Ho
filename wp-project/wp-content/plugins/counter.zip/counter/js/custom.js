// $(document).ready(function() {
//     $('.widefat').click(function() {
//         if ($(this).attr('value') == '0') {
//             $(this).attr("value", 1);
//         } else {
//             $(this).attr("value", 0);
//         }
//     });
// });